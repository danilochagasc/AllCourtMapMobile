export default {
    black: '#000000',
    white: '#FFFFFF',
    orange: '#F87138',
    brownLight: '#b6a6a6',
    gray: '#C6C6C6',
    blue: '#413F92',
    red: '#C82929'
  }