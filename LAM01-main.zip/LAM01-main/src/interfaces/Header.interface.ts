import {ImageSourcePropType} from "react-native"

export interface HeaderProps{
    title?: string;
    image?: ImageSourcePropType;
}