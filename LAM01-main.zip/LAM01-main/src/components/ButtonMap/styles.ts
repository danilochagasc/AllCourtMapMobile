// import styled from "styled-components/native";
// import colors from "../../styles/colors";


// export const ButtonStyle = styled.TouchableOpacity`
// `

// export const Imagem = styled.Image``