// import React from "react";
// import { ButtonProps } from "../../interfaces/Button.interface";
// import { Imagem, ButtonStyle } from "./styles";

// export default function Button({title, image, onPress, ...rest}:ButtonProps){
//     return(
//         <ButtonStyle onPress={onPress} {...rest}>
//             <Imagem source={image} />
//         </ButtonStyle>
//     );
// }