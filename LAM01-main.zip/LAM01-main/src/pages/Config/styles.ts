import styled from "styled-components/native";

export const Switch = styled.Switch`
`