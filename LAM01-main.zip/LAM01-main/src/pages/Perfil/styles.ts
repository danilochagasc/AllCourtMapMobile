import styled from 'styled-components/native'
// import {ImageSourcePropType} from "react-native"


export const TextInput = styled.TextInput`
  border-bottom-width: 1px;
  font-size: 18px;
  padding: 5px;
  margin-left: 5px;
  margin-bottom: 5px;
  width: 65%;
  left: 55px;
  top: 466px;
`

export const Text = styled.Text`
  border-bottom-width: 1px;
  font-size: 18px;
  padding: 5px;
  margin-left: 5px;
  margin-bottom: 5px;
  width: 65%;
  left: 121px;
  top: 349px;

`